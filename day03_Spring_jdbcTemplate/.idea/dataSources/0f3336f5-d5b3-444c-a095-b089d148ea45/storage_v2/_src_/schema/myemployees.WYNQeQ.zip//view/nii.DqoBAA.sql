create definer = root@localhost view nii as
select `e`.`last_name` AS `last_name`
from ((`myemployees`.`employees` `e` join `myemployees`.`departments` `d` on ((`e`.`department_id` = `d`.`department_id`)))
         join `myemployees`.`jobs` `j` on ((`e`.`job_id` = `j`.`job_id`)));

